# Backend

Flask application, authentication, API/routes, Socket.IO events, services and models.
