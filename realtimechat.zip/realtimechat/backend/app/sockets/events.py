from datetime import datetime, timezone
from flask import request
from flask_login import current_user
from flask_socketio import join_room, emit

from app import db, socketio
from app.models.conversation import Conversation
from app.models.message import Message

# Tracks every active Socket.IO session per user (multiple tabs supported).
online_sessions = {}
sid_to_user = {}


def broadcast_presence():
    emit(
        "presence_update",
        {"online_user_ids": list(online_sessions.keys())},
        broadcast=True,
    )


def get_authorized_conversation(conversation_id):
    """Return the conversation only when the current user belongs to it."""
    try:
        conversation_id = int(conversation_id)
    except (TypeError, ValueError):
        return None

    conversation = db.session.get(Conversation, conversation_id)
    if conversation is None:
        return None

    if current_user.id not in (conversation.user1_id, conversation.user2_id):
        return None

    return conversation


@socketio.on("connect")
def handle_connect(auth=None):
    if not current_user.is_authenticated:
        return False

    user_id = current_user.id
    sid = request.sid
    online_sessions.setdefault(user_id, set()).add(sid)
    sid_to_user[sid] = user_id
    print(f"Socket connected: user {user_id}")
    broadcast_presence()


@socketio.on("disconnect")
def handle_disconnect(reason=None):
    sid = request.sid
    user_id = sid_to_user.pop(sid, None)

    if user_id is not None:
        sessions = online_sessions.get(user_id, set())
        sessions.discard(sid)

        if not sessions:
            online_sessions.pop(user_id, None)

        broadcast_presence()
        print(f"Socket disconnected: user {user_id}")


@socketio.on("join_conversation")
def handle_join(data):
    if not current_user.is_authenticated or not isinstance(data, dict):
        return

    conversation = get_authorized_conversation(data.get("conversation_id"))
    if conversation is not None:
        join_room(f"conversation_{conversation.id}")


@socketio.on("typing")
def handle_typing(data):
    if not current_user.is_authenticated or not isinstance(data, dict):
        return

    conversation = get_authorized_conversation(data.get("conversation_id"))
    if conversation is None:
        return

    emit(
        "typing_status",
        {
            "user_id": current_user.id,
            "username": current_user.username,
            "is_typing": bool(data.get("is_typing")),
            "conversation_id": conversation.id,
        },
        to=f"conversation_{conversation.id}",
        include_self=False,
    )


@socketio.on("send_message")
def handle_send_message(data):
    if not current_user.is_authenticated or not isinstance(data, dict):
        return

    conversation = get_authorized_conversation(data.get("conversation_id"))
    if conversation is None:
        emit("message_error", {"error": "Conversation not found."})
        return

    body = str(data.get("body", "")).strip()
    if not body or len(body) > 4000:
        emit("message_error", {"error": "Message must be 1–4000 characters."})
        return

    message = Message(
        conversation_id=conversation.id,
        sender_id=current_user.id,
        body=body,
    )
    db.session.add(message)
    db.session.commit()

    emit(
        "new_message",
        {
            "id": message.id,
            "conversation_id": message.conversation_id,
            "sender_id": message.sender_id,
            "body": message.body,
            "created_at": message.created_at.isoformat() + "Z",
            "read_at": None,
            "is_edited": False,
        },
        to=f"conversation_{conversation.id}",
    )


@socketio.on("edit_message")
def handle_edit_message(data):
    if not current_user.is_authenticated or not isinstance(data, dict):
        return

    try:
        message_id = int(data.get("message_id"))
    except (TypeError, ValueError):
        emit("message_error", {"error": "Invalid message."})
        return

    message = db.session.get(Message, message_id)
    if message is None or message.sender_id != current_user.id:
        emit("message_error", {"error": "You can only edit your own messages."})
        return

    conversation = db.session.get(Conversation, message.conversation_id)
    if conversation is None or current_user.id not in (
        conversation.user1_id,
        conversation.user2_id,
    ):
        emit("message_error", {"error": "Conversation not found."})
        return

    body = str(data.get("body", "")).strip()
    if not body or len(body) > 4000:
        emit("message_error", {"error": "Message must be 1–4000 characters."})
        return

    message.body = body
    db.session.commit()

    emit(
        "message_updated",
        {
            "id": message.id,
            "conversation_id": message.conversation_id,
            "sender_id": message.sender_id,
            "body": message.body,
            "created_at": message.created_at.isoformat() + "Z",
            "is_edited": True,
        },
        to=f"conversation_{conversation.id}",
    )


@socketio.on("delete_message")
def handle_delete_message(data):
    if not current_user.is_authenticated or not isinstance(data, dict):
        return

    try:
        message_id = int(data.get("message_id"))
    except (TypeError, ValueError):
        emit("message_error", {"error": "Invalid message."})
        return

    message = db.session.get(Message, message_id)
    if message is None or message.sender_id != current_user.id:
        emit("message_error", {"error": "You can only delete your own messages."})
        return

    conversation_id = message.conversation_id
    conversation = db.session.get(Conversation, conversation_id)
    if conversation is None or current_user.id not in (
        conversation.user1_id,
        conversation.user2_id,
    ):
        emit("message_error", {"error": "Conversation not found."})
        return

    db.session.delete(message)
    db.session.commit()

    emit(
        "message_deleted",
        {"message_id": message_id, "conversation_id": conversation_id},
        to=f"conversation_{conversation_id}",
    )


@socketio.on("mark_conversation_read")
def handle_mark_conversation_read(data):
    """Mark messages from the other participant as read for this user."""
    if not current_user.is_authenticated or not isinstance(data, dict):
        return

    conversation = get_authorized_conversation(data.get("conversation_id"))
    if conversation is None:
        return

    unread_messages = Message.query.filter(
        Message.conversation_id == conversation.id,
        Message.sender_id != current_user.id,
        Message.read_at.is_(None),
    ).all()

    now = datetime.now(timezone.utc).replace(tzinfo=None)
    message_ids = []
    sender_ids = set()
    for message in unread_messages:
        message.read_at = now
        message_ids.append(message.id)
        sender_ids.add(message.sender_id)

    if unread_messages:
        db.session.commit()

        receipt_payload = {
            "conversation_id": conversation.id,
            "message_ids": message_ids,
            "read_at": now.isoformat() + "Z",
            "reader_id": current_user.id,
        }

        # Keep the conversation-room broadcast, and also notify every active
        # socket belonging to each original sender. This makes blue read ticks
        # reliable even if the sender's socket has not joined the room yet.
        emit("messages_read", receipt_payload, to=f"conversation_{conversation.id}")
        for sender_id in sender_ids:
            for sender_sid in online_sessions.get(sender_id, set()):
                socketio.emit("messages_read", receipt_payload, to=sender_sid)

    emit("unread_counts", {"counts": {str(conversation.id): 0}}, to=request.sid)
