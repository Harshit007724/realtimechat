
from app import db


class Conversation(db.Model):
    __tablename__ = "conversations"

    id = db.Column(db.Integer, primary_key=True)
    user1_id = db.Column(
        db.Integer, db.ForeignKey("users.id"), nullable=False
    )
    user2_id = db.Column(
        db.Integer, db.ForeignKey("users.id"), nullable=False
    )

    __table_args__ = (
        db.UniqueConstraint(
            "user1_id", "user2_id", name="unique_conversation_pair"
        ),
    )
