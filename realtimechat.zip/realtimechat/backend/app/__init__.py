
import os
from pathlib import Path

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_socketio import SocketIO
from dotenv import load_dotenv

db = SQLAlchemy()
login_manager = LoginManager()
socketio = SocketIO()


def create_app():
    project_root = Path(__file__).resolve().parents[2]
    load_dotenv(project_root / ".env")

    app = Flask(
        __name__,
        template_folder=str(project_root / "frontend" / "templates"),
        static_folder=str(project_root / "frontend" / "static"),
    )

    app.config["SECRET_KEY"] = os.getenv(
        "SECRET_KEY",
        "development-key-change-this",
    )
    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)
    login_manager.init_app(app)
    socketio.init_app(app)

    login_manager.login_view = "auth.login"

    from app.models.user import User

    @login_manager.user_loader
    def load_user(user_id):
        try:
            return db.session.get(User, int(user_id))
        except (TypeError, ValueError):
            return None

    from app.auth.routes import auth
    from app.routes.chat import chat

    app.register_blueprint(auth)
    app.register_blueprint(chat)

    # Import models so SQLAlchemy can create their tables.
    from app.models.conversation import Conversation
    from app.models.message import Message
    from app.models.community import Community, CommunityMembership, CommunityPost

    # Register Socket.IO event handlers.
    from app.sockets import events

    return app


