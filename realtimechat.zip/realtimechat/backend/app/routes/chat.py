
from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from uuid import uuid4
from pathlib import Path

from app import db
from app.models.user import User
from app.models.conversation import Conversation
from app.models.message import Message

chat = Blueprint("chat", __name__)


def is_participant(conversation):
    return current_user.id in (
        conversation.user1_id,
        conversation.user2_id,
    )


@chat.route("/")
@login_required
def index():
    return render_template("chat.html", current_user=current_user)


@chat.route("/api/users")
@login_required
def search_users():
    query = request.args.get("q", "").strip()

    users = User.query.filter(
        User.id != current_user.id,
        User.username.ilike(f"%{query}%"),
    ).order_by(User.username).limit(20).all()

    return jsonify([
        {"id": user.id, "username": user.username, "display_name": user.display_name or user.username, "avatar_url": url_for("static", filename="uploads/" + user.avatar_filename) if user.avatar_filename else None}
        for user in users
    ])


@chat.route("/api/conversations", methods=["GET", "POST"])
@login_required
def conversations():
    if request.method == "POST":
        data = request.get_json(silent=True) or {}

        try:
            other_id = int(data.get("user_id"))
        except (TypeError, ValueError):
            return jsonify({"error": "Invalid user ID"}), 400

        if other_id == current_user.id:
            return jsonify({"error": "Cannot chat with yourself"}), 400

        other = db.session.get(User, other_id)
        if other is None:
            return jsonify({"error": "User not found"}), 404

        first, second = sorted([current_user.id, other_id])

        conversation = Conversation.query.filter_by(
            user1_id=first, user2_id=second
        ).first()

        if conversation is None:
            conversation = Conversation(
                user1_id=first, user2_id=second
            )
            db.session.add(conversation)
            db.session.commit()

        return jsonify({
            "id": conversation.id,
            "other_user": {
                "id": other.id,
                "username": other.username,
                "display_name": other.display_name or other.username,
                "avatar_url": url_for("static", filename="uploads/" + other.avatar_filename) if other.avatar_filename else None,
            },
        })

    rows = Conversation.query.filter(
        db.or_(
            Conversation.user1_id == current_user.id,
            Conversation.user2_id == current_user.id,
        )
    ).all()

    result = []
    for conversation in rows:
        other_id = (
            conversation.user2_id
            if conversation.user1_id == current_user.id
            else conversation.user1_id
        )
        other = db.session.get(User, other_id)

        if other:
            last = Message.query.filter_by(
                conversation_id=conversation.id
            ).order_by(Message.id.desc()).first()

            unread_count = Message.query.filter(
                Message.conversation_id == conversation.id,
                Message.sender_id != current_user.id,
                Message.read_at.is_(None),
            ).count()

            result.append({
                "id": conversation.id,
                "other_user": {
                    "id": other.id,
                    "username": other.username,
                "display_name": other.display_name or other.username,
                "avatar_url": url_for("static", filename="uploads/" + other.avatar_filename) if other.avatar_filename else None,
                },
                "last_message": last.body if last else "",
                "unread_count": unread_count,
            })

    return jsonify(result)


@chat.route("/api/conversations/<int:conversation_id>/messages")
@login_required
def conversation_messages(conversation_id):
    conversation = db.session.get(Conversation, conversation_id)

    if conversation is None or not is_participant(conversation):
        return jsonify({"error": "Conversation not found"}), 404

    messages = Message.query.filter_by(
        conversation_id=conversation_id
    ).order_by(Message.id.asc()).limit(200).all()

    return jsonify([
    {
        "id": message.id,
        "sender_id": message.sender_id,
        "body": message.body,
        "created_at": message.created_at.isoformat() + "Z",
        "read_at": (
            message.read_at.isoformat() + "Z"
            if message.read_at else None
        ),
    }
    for message in messages
])
        


@chat.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        display_name = request.form.get("display_name", "").strip()
        bio = request.form.get("bio", "").strip()
        uploaded = request.files.get("avatar")

        if not display_name:
            flash("Display name cannot be empty.")
            return redirect(url_for("chat.profile"))
        if len(display_name) > 80 or len(bio) > 300:
            flash("Display name or bio is too long.")
            return redirect(url_for("chat.profile"))

        if uploaded and uploaded.filename:
            allowed_extensions = {"png", "jpg", "jpeg", "webp", "gif"}
            extension = uploaded.filename.rsplit(".", 1)[-1].lower() if "." in uploaded.filename else ""
            if extension not in allowed_extensions or uploaded.mimetype not in {"image/png", "image/jpeg", "image/webp", "image/gif"}:
                flash("Choose a PNG, JPG, WEBP, or GIF image.")
                return redirect(url_for("chat.profile"))
            uploaded.stream.seek(0, 2)
            size = uploaded.stream.tell()
            uploaded.stream.seek(0)
            if size > 10 * 1024 * 1024:
                flash("Profile images must be 10 MB or smaller.")
                return redirect(url_for("chat.profile"))

            upload_dir = Path(current_app.static_folder) / "uploads"
            upload_dir.mkdir(parents=True, exist_ok=True)
            filename = f"avatar_{current_user.id}_{uuid4().hex}.{extension}"
            uploaded.save(upload_dir / secure_filename(filename))
            old_filename = current_user.avatar_filename
            current_user.avatar_filename = filename
            if old_filename:
                old_path = upload_dir / secure_filename(old_filename)
                try:
                    if old_path.exists(): old_path.unlink()
                except OSError:
                    pass

        current_user.display_name = display_name
        current_user.bio = bio or None
        db.session.commit()
        flash("Profile saved successfully.")
        return redirect(url_for("chat.profile"))

    return render_template("profile.html", current_user=current_user)


@chat.route("/communities", methods=["GET", "POST"])
@login_required
def communities():
    from re import sub
    from app.models.community import Community, CommunityMembership, CommunityPost

    if request.method == "POST":
        action = request.form.get("action", "").strip()
        community_id = request.form.get("community_id", type=int)
        if action == "create":
            name = request.form.get("name", "").strip()
            description = request.form.get("description", "").strip()
            category = request.form.get("category", "General").strip() or "General"
            if len(name) < 3 or len(name) > 80 or len(description) > 500:
                flash("Use a community name between 3 and 80 characters and a description under 500 characters.")
                return redirect(url_for("chat.communities"))
            slug_base = sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "community"
            slug = slug_base
            suffix = 2
            while Community.query.filter_by(slug=slug).first():
                slug = f"{slug_base}-{suffix}"
                suffix += 1
            if Community.query.filter(db.func.lower(Community.name) == name.lower()).first():
                flash("A community with that name already exists.")
                return redirect(url_for("chat.communities"))
            community = Community(name=name, slug=slug, description=description, category=category[:40], owner_id=current_user.id)
            db.session.add(community)
            db.session.flush()
            db.session.add(CommunityMembership(community_id=community.id, user_id=current_user.id))
            db.session.commit()
            flash(f"Your community, {name}, is live!")
            return redirect(url_for("chat.communities", community=community.slug))

        community = db.session.get(Community, community_id) if community_id else None
        if not community:
            flash("That community could not be found.")
            return redirect(url_for("chat.communities"))
        membership = CommunityMembership.query.filter_by(community_id=community.id, user_id=current_user.id).first()
        if action == "join" and not membership:
            db.session.add(CommunityMembership(community_id=community.id, user_id=current_user.id))
            db.session.commit()
            flash(f"You joined {community.name}.")
        elif action == "leave" and membership:
            if community.owner_id == current_user.id:
                flash("Community owners cannot leave their own community. You can keep it or delete it later.")
            else:
                db.session.delete(membership)
                db.session.commit()
                flash(f"You left {community.name}.")
        elif action == "post":
            body = request.form.get("body", "").strip()
            if not membership:
                flash("Join this community before posting.")
            elif not body or len(body) > 2000:
                flash("Posts must be between 1 and 2000 characters.")
            else:
                db.session.add(CommunityPost(community_id=community.id, author_id=current_user.id, body=body))
                db.session.commit()
                flash("Post published.")
        return redirect(url_for("chat.communities", community=community.slug))

    selected_slug = request.args.get("community", "").strip()
    selected = Community.query.filter_by(slug=selected_slug).first() if selected_slug else None
    all_communities = Community.query.order_by(Community.created_at.desc()).all()
    member_ids = {m.community_id for m in CommunityMembership.query.filter_by(user_id=current_user.id).all()}
    if selected is None and all_communities:
        selected = next((c for c in all_communities if c.id in member_ids), all_communities[0])
    posts = []
    selected_is_member = False
    if selected:
        selected_is_member = selected.id in member_ids
        posts = CommunityPost.query.filter_by(community_id=selected.id).order_by(CommunityPost.created_at.desc()).limit(50).all()
    return render_template("communities.html", communities=all_communities, member_ids=member_ids, selected=selected, selected_is_member=selected_is_member, posts=posts, CommunityMembership=CommunityMembership)
