# Frontend

HTML templates, CSS, JavaScript, images and icons for the chat application.
