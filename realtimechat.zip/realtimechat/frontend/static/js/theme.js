(() => {
  const key = 'realtimechat-theme';
  const themes = ['violet','ocean','forest','sunset','midnight'];
  const apply = value => {
    const theme = themes.includes(value) ? value : 'violet';
    document.documentElement.dataset.theme = theme;
    if (document.body) document.body.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme === 'midnight' ? 'dark' : 'light';
    return theme;
  };
  let saved = 'violet';
  try { saved = localStorage.getItem(key) || 'violet'; } catch (_) {}
  apply(saved);
  window.addEventListener('storage', e => { if (e.key === key) apply(e.newValue || 'violet'); });
  window.RealTimeChatTheme = { key, get: () => document.documentElement.dataset.theme || 'violet', apply: (v) => { const t=apply(v); try{localStorage.setItem(key,t)}catch(_){} return t; } };
})();
