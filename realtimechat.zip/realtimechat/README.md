# RealTimeChat

A real-time messaging web application built using Flask, Socket.IO, and MySQL.

## 1. Major Features

- User registration and login
- Private one-to-one conversations
- Real-time messaging
- Persistent message storage
- Online/offline status
- Typing indicators and read receipts
- Message search, editing, and deletion
- User profiles
- Dark mode and chat wallpapers
- Chat wallpapers

## 2. Technology Stack

- **Frontend:** HTML, CSS, JavaScript
- **Backend:** Python, Flask
- **Real-time communication:** Flask-SocketIO and Socket.IO
- **Database:** MySQL
- **ORM:** Flask-SQLAlchemy
- **Authentication:** Flask-Login
- **Database driver:** PyMySQL
- **Environment configuration:** python-dotenv

## 3. Application Architecture

The browser communicates with the Flask backend using HTTP requests and Socket.IO connections. Flask handles authentication and chat operations. Socket.IO enables real-time events, while SQLAlchemy communicates with MySQL to store application data.

```text
Browser
   |
   | HTTP + Socket.IO
   v
Flask Backend
   |
   | SQLAlchemy
   v
MySQL Database
```

## 4. Project Structure

```text
realtimechat/
├── backend/
│   ├── run.py
│   └── app/
│       └── __init__.py
├── frontend/
│   ├── templates/
│   └── static/
├── database/
├── uploads/
├── .env
└── README.md
```

## 5. Requirements

- Python 3.10 or newer recommended
- MySQL Server
- Git
- A web browser

## 6. Installation and Local Setup

### Step 1: Clone the repository

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd realtimechat
```

### Step 2: Create a virtual environment

**Windows:**

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

**macOS/Linux:**

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### Step 3: Install dependencies

```bash
pip install Flask Flask-SocketIO Flask-SQLAlchemy Flask-Login PyMySQL python-dotenv
```

If a `requirements.txt` file exists, prefer:

```bash
pip install -r requirements.txt
```

### Step 4: Create the MySQL database

Run the following SQL in MySQL:

```sql
CREATE DATABASE realtimechat
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

### Step 5: Configure environment variables

Create a `.env` file in the project root:

```dotenv
SECRET_KEY=replace_with_a_secure_random_secret
DATABASE_URL=mysql+pymysql://DB_USER:DB_PASSWORD@127.0.0.1:3306/realtimechat
```

Replace `DB_USER` and `DB_PASSWORD` with your MySQL credentials.

- `SECRET_KEY`: protects Flask session-related data.
- `DATABASE_URL`: specifies the MySQL connection.

**Never commit `.env` or database credentials to GitHub.**

### Step 6: Start the application

From the project root:

```bash
python backend/run.py
```

Open the local address displayed in the terminal, commonly `http://127.0.0.1:5000`.

Confirm the startup command against the actual project code.

## 7. Reproducing and Testing

To reproduce the application in a clean environment:

1. Install the dependencies.
2. Create a fresh MySQL database.
3. Configure the required environment variables.
4. Start the Flask application.
5. Register two test accounts.
6. Open the accounts in separate browsers or private windows.
7. Send messages in both directions and check that they arrive without refreshing.
8. Refresh the browsers and verify that messages remain saved.
9. Test typing indicators, online status, read receipts, search, editing, and deletion.
10. Restart the application and confirm that messages remain stored in MySQL.

Document any failed tests rather than claiming unverified functionality.

## 8. External Services and Deployment

For public access, the application requires:

- A hosting service that supports Flask and the application's Socket.IO configuration.
- A reachable MySQL database.
- Correct production environment variables.
- A public HTTPS domain.

Configure production secrets in the hosting provider's environment settings. Do not expose database credentials in frontend code.

## 9. Troubleshooting

- **Database connection fails:** Check MySQL status and `DATABASE_URL`.
- **Module not found:** Activate the virtual environment and install dependencies.
- **Messages do not arrive live:** Check browser and server logs and test using two accounts.
- **Messages disappear after refresh:** Check database writes and reads.
- **Deployment fails:** Verify the startup command, environment variables, database connectivity, and Socket.IO support.

## 10. GitHub and Hackathon Submission

- Keep the repository **private until the hackathon ends**.
- Make it public when submitting the final entry, as permitted or required by the event rules.
- Include the complete source code and this README.
- Exclude virtual environments, `.env` files, and secrets.
- Provide a publicly accessible demo video link.
- Ensure any required presentation link is accessible to reviewers.

## 11. Security

- Use a strong, private production `SECRET_KEY`.
- Never upload credentials to GitHub.
- Use HTTPS for public deployment.
- Use a dedicated MySQL account with limited permissions.
- Use test accounts and non-sensitive messages during demonstrations.

---

**Note:** This README describes the known project structure and intended features. Verify the dependency versions, startup command, configuration, and features against the final source code before submission.
